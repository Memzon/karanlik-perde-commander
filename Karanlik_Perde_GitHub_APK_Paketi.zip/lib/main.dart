import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

void main() => runApp(const KaranlikPerdeApp());

class KaranlikPerdeApp extends StatelessWidget {
  const KaranlikPerdeApp({super.key});

  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF090B10);
    const panel = Color(0xFF151923);
    const accent = Color(0xFFB20D30);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Karanlık Perde Commander',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: accent,
          brightness: Brightness.dark,
          surface: panel,
        ),
        useMaterial3: true,
      ),
      home: const Dashboard(),
    );
  }
}

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  String? selectedVideo;
  bool privateVisibility = true;

  Future<void> chooseVideo() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.video,
      withData: false,
    );
    if (result != null && result.files.isNotEmpty) {
      setState(() => selectedVideo = result.files.first.name);
    }
  }

  void showUploadNotice() {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('YouTube bağlantısı gerekli'),
        content: const Text(
          'Video seçildiğinde bu başlangıç sürümü henüz YouTube’a yükleme yapmaz. '
          'Gerçek yükleme için Google Cloud Console’da YouTube Data API v3 ve OAuth '
          'yetkilendirmesi yapılandırılmalıdır. Gizlilik tercihin: '
          'Gizli (Private).',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tamam'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('KARANLIK PERDE',
            style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.3)),
        centerTitle: false,
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.movie_filter_outlined, color: Color(0xFFE53958)),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF38101C), Color(0xFF171923)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFF612033)),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('COMMAND CENTER',
                      style: TextStyle(
                        color: Color(0xFFFF8094),
                        fontSize: 11,
                        letterSpacing: 2.2,
                        fontWeight: FontWeight.bold,
                      )),
                  SizedBox(height: 12),
                  Text('Videoların kontrolü\ntek ekranda.',
                      style: TextStyle(
                        fontSize: 28,
                        height: 1.15,
                        fontWeight: FontWeight.w900,
                      )),
                  SizedBox(height: 10),
                  Text('Seç • Hazırla • Yayın akışını yönet',
                      style: TextStyle(color: Colors.white70)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text('YAYIN PANELİ',
                style: TextStyle(
                    fontSize: 12,
                    letterSpacing: 1.8,
                    fontWeight: FontWeight.bold,
                    color: Colors.white60)),
            const SizedBox(height: 12),
            _InfoTile(
              icon: Icons.video_library_outlined,
              title: 'Video kaynağı',
              subtitle: selectedVideo ?? 'Henüz video seçilmedi',
              trailing: TextButton(
                onPressed: chooseVideo,
                child: const Text('SEÇ'),
              ),
            ),
            const SizedBox(height: 10),
            _InfoTile(
              icon: Icons.lock_outline,
              title: 'Görünürlük',
              subtitle: privateVisibility ? 'Gizli (Private)' : 'Liste dışı',
              trailing: Switch(
                value: privateVisibility,
                onChanged: (v) => setState(() => privateVisibility = v),
              ),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(56),
                backgroundColor: const Color(0xFFB20D30),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
              onPressed: selectedVideo == null ? chooseVideo : showUploadNotice,
              icon: const Icon(Icons.cloud_upload_outlined),
              label: Text(
                selectedVideo == null ? 'ÖNCE VİDEO SEÇ' : 'YOUTUBE YÜKLEMEYİ HAZIRLA',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(height: 22),
            const Text('SİSTEM DURUMU',
                style: TextStyle(
                    fontSize: 12,
                    letterSpacing: 1.8,
                    fontWeight: FontWeight.bold,
                    color: Colors.white60)),
            const SizedBox(height: 12),
            const _StatusRow(label: 'Arayüz', value: 'Hazır', ok: true),
            const _StatusRow(label: 'Video seçimi', value: 'Cihazdan', ok: true),
            const _StatusRow(label: 'YouTube API', value: 'Yapılandırılmadı', ok: false),
            const SizedBox(height: 20),
            const Text(
              'Not: Bu APK başlangıç arayüzüdür. YouTube’a gerçek yükleme yapabilmesi için Google OAuth/API kurulumu gerekir.',
              style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.trailing,
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget trailing;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF151923),
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: Colors.white10),
        ),
        child: Row(
          children: [
            Container(
              height: 44,
              width: 44,
              decoration: BoxDecoration(
                color: const Color(0xFFB20D30).withValues(alpha: .16),
                borderRadius: BorderRadius.circular(13),
              ),
              child: Icon(icon, color: const Color(0xFFFF8094)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 3),
                  Text(subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white60, fontSize: 12)),
                ],
              ),
            ),
            trailing,
          ],
        ),
      );
}

class _StatusRow extends StatelessWidget {
  const _StatusRow({required this.label, required this.value, required this.ok});
  final String label;
  final String value;
  final bool ok;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(
          children: [
            Icon(ok ? Icons.check_circle : Icons.pending,
                size: 18, color: ok ? const Color(0xFF5DD39E) : Colors.orangeAccent),
            const SizedBox(width: 10),
            Expanded(child: Text(label)),
            Text(value, style: const TextStyle(color: Colors.white60, fontSize: 12)),
          ],
        ),
      );
}
