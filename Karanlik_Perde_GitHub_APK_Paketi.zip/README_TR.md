# Karanlık Perde Commander

Bu paket, Android APK'yı GitHub Actions üzerinde derlemek için Flutter kaynak projesidir.

## Telefonda APK oluşturma
1. GitHub'da `karanlik-perde-commander` adında bir repository oluştur.
2. Bu ZIP'in içindeki dosyaları ZIP'in kendisini değil, **içeriğini** repository'ye yükle.
3. `.github/workflows/build-apk.yml` dosyası da yüklenmiş olmalı.
4. GitHub'da repository > Actions > `Build Android APK` > `Run workflow` yolunu izle.
5. İşlem tamamlanınca çalıştırmayı açıp alttaki **Artifacts** bölümünden `karanlik-perde-apk` dosyasını indir.
6. İndirilen ZIP'i aç ve `app-release.apk` dosyasını Android'e kur.

## YouTube yükleme
Bu başlangıç sürümünde dashboard ve video seçme arayüzü bulunur. Gerçek YouTube yüklemesi için Google Cloud Console'da YouTube Data API v3, OAuth istemcisi ve uygulama imza ayarları yapılandırılmalıdır. Bu yapılandırma olmadan uygulama videoyu YouTube'a yüklediğini iddia etmez. Varsayılan gizlilik tercihi `private` olarak gösterilir.
